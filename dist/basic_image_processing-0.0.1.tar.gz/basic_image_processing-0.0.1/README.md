# basic-image-processing

Description. 
The package basic-image-processing is used to:
	Processing:
		- Histogram Matching
		- Structural Similarity
		- Resize Imagem
	Utils:
		- Read Image
		- Save Image
		- Plot Image
		- Plot Result
		- Plot Histogram
	

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install basic-image-processing

```bash
pip install basic-image-processing
```

## Author
Josevpc

## License
[MIT](https://choosealicense.com/licenses/mit/)